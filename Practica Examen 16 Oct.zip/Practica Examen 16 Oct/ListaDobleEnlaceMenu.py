""" 
Ejercicio hecho el día 16 de Octubre de 2025
Implementación de una lista doblemente enlazada con un menú interactivo.
Mario Damián Aguileta Argueta
Estructuras de Datos
"""
class Nodo:
    def __init__(self, elemento):
        self.elemento = elemento
        self.siguiente = None
        self.anterior = None

class ListaDoble:
    def __init__(self):
        self.root = None

    def insertar_lista_vacia(self, dato):
        if self.root is None:
            nuevo = Nodo(dato)
            self.root = nuevo
        else:
            print("Error: La lista no está vacía.")

    def insertar_inicio(self, dato):
        if self.root is None:
            self.insertar_lista_vacia(dato)
            return
        else:
            nuevo = Nodo(dato)
            nuevo.siguiente = self.root
            self.root.anterior = nuevo
            self.root = nuevo

    def insertar_final(self, dato):
        if self.root is None:
            self.insertar_lista_vacia(dato)
            return

        apuntador = self.root
        while apuntador.siguiente is not None:
            apuntador = apuntador.siguiente
        
        nuevo_nodo = Nodo(dato)
        apuntador.siguiente = nuevo_nodo
        nuevo_nodo.anterior = apuntador

    def insertar_despues_elemento(self, x, dato):
        if self.root is None:
            print("La lista está vacía.")
            return

        apuntador = self.root
        while apuntador is not None:
            if apuntador.elemento == x:
                break
            apuntador = apuntador.siguiente
        
        if apuntador is None:
            print(f"El elemento {x} no se encuentra en la lista.")
        else:
            nuevo_nodo = Nodo(dato)
            nuevo_nodo.siguiente = apuntador.siguiente
            nuevo_nodo.anterior = apuntador
            
            if apuntador.siguiente is not None:
                apuntador.siguiente.anterior = nuevo_nodo
            
            apuntador.siguiente = nuevo_nodo

    def insertar_antes_elemento(self, x, dato):
        if self.root is None:
            print("La lista está vacía.")
            return

        apuntador = self.root
        while apuntador is not None:
            if apuntador.elemento == x:
                break
            apuntador = apuntador.siguiente
            
        if apuntador is None:
            print(f"El elemento {x} no se encuentra en la lista.")
            return
            
        nuevo_nodo = Nodo(dato)
        nuevo_nodo.siguiente = apuntador
        nuevo_nodo.anterior = apuntador.anterior
        
        if apuntador.anterior is not None:
            apuntador.anterior.siguiente = nuevo_nodo
        else:
            self.root = nuevo_nodo
            
        apuntador.anterior = nuevo_nodo

    def navegar_lista(self):
        if self.root is None:
            print("La lista está vacía.")
            return
        
        print("Elementos de la lista:")
        apuntador = self.root
        elementos_str = ""
        while apuntador is not None:
            elementos_str += str(apuntador.elemento) + " <-> "
            apuntador = apuntador.siguiente
        print(elementos_str + "None")

    def lista_vacia(self):
        return self.root is None

    def contar_elementos(self):
        if self.root is None:
            return 0
        
        cuenta = 0
        apuntador = self.root
        while apuntador is not None:
            cuenta += 1
            apuntador = apuntador.siguiente
        return cuenta

    def eliminar_inicio(self):
        if self.root is None:
            print("La lista está vacía, no se puede eliminar.")
            return
            
        if self.root.siguiente is None:
            self.root = None
        else:
            self.root = self.root.siguiente
            self.root.anterior = None
        print("Elemento inicial eliminado.")

    def eliminar_final(self):
        if self.root is None:
            print("La lista está vacía, no se puede eliminar.")
            return
            
        if self.root.siguiente is None:
            self.root = None
            print("Elemento final eliminado.")
            return
            
        apuntador = self.root
        while apuntador.siguiente is not None:
            apuntador = apuntador.siguiente
            
        apuntador.anterior.siguiente = None
        print("Elemento final eliminado.")

    def eliminar_elemento(self, x):
        if self.root is None:
            print("La lista está vacía.")
            return

        if self.root.elemento == x:
            self.eliminar_inicio()
            return
        
        apuntador = self.root
        while apuntador is not None:
            if apuntador.elemento == x:
                break
            apuntador = apuntador.siguiente

        if apuntador is None:
            print(f"El elemento {x} no fue encontrado.")
        else:
            if apuntador.siguiente is None:
                self.eliminar_final()
            else:
                apuntador.anterior.siguiente = apuntador.siguiente
                apuntador.siguiente.anterior = apuntador.anterior
                print(f"Elemento {x} eliminado.")

def mostrar_menu():
    """Función para mostrar el menú de opciones."""
    print("""\n--- MENÚ LISTA DOBLEMENTE ENLAZADA ---"
    1. Insertar un elemento al inicio"
    2. Insertar un elemento al final"
    3. Insertar un elemento después de otro"
    4. Insertar un elemento antes de otro"
    5. Mostrar la lista"
    6. Contar elementos de la lista"
    7. Verificar si la lista está vacía"
    8. Eliminar el primer elemento"
    9. Eliminar el último elemento"
    10. Eliminar un elemento específico"
    11. Salir""")
    print("-"*36)

if __name__ == "__main__":
    lista = ListaDoble()

    while True:
        mostrar_menu()
        try:
            opcion = int(input("Elige una opción: "))

            if opcion == 1:
                dato = input("Ingresa el dato a insertar al inicio: ")
                lista.insertar_inicio(dato)
                print(f"'{dato}' ha sido insertado.")
            
            elif opcion == 2:
                dato = input("Ingresa el dato a insertar al final: ")
                lista.insertar_final(dato)
                print(f"'{dato}' ha sido insertado.")

            elif opcion == 3:
                elemento_ref = input("Ingresa el elemento de referencia: ")
                dato = input(f"Ingresa el dato a insertar después de '{elemento_ref}': ")
                lista.insertar_despues_elemento(elemento_ref, dato)

            elif opcion == 4:
                elemento_ref = input("Ingresa el elemento de referencia: ")
                dato = input(f"Ingresa el dato a insertar antes de '{elemento_ref}': ")
                lista.insertar_antes_elemento(elemento_ref, dato)

            elif opcion == 5:
                lista.navegar_lista()

            elif opcion == 6:
                print(f"La lista tiene {lista.contar_elementos()} elementos.")

            elif opcion == 7:
                if lista.lista_vacia():
                    print("La lista está vacía.")
                else:
                    print("La lista NO está vacía.")

            elif opcion == 8:
                lista.eliminar_inicio()

            elif opcion == 9:
                lista.eliminar_final()
            
            elif opcion == 10:
                dato = input("Ingresa el elemento que deseas eliminar: ")
                lista.eliminar_elemento(dato)
            
            elif opcion == 11:
                print("Saliendo del programa. ¡Hasta luego!")
                break
            
            else:
                print("Opción no válida. Por favor, intenta de nuevo.")
        
        except ValueError:
            print("Entrada inválida. Por favor, ingresa un número.")





