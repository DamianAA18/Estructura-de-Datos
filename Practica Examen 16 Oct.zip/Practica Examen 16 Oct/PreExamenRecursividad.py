
""" 
Ejercicio hecho el día 16 de Octubre de 2025
Implementación de una lista doblemente enlazada con un menú interactivo.
Mario Damián Aguileta Argueta
Estructuras de Datos
"""

class Nodo:
    def __init__(self, nombre, calificacion):
        self.nombre = nombre
        self.calificacion = float(calificacion)
        self.siguiente = None
        self.anterior = None


class ListaDoblementeLigada:
    def __init__(self):
        self.cabeza = None
        self.cola = None

    def esta_vacia(self):
        return self.cabeza is None

    def agregar_alumno(self, nombre, calificacion):
        nuevo_nodo = Nodo(nombre, calificacion)
        if self.esta_vacia():
            self.cabeza = nuevo_nodo
            self.cola = nuevo_nodo
        else:
            self._agregar_recursivo(self.cabeza, nuevo_nodo)
        print(f"¡Alumno '{nombre}' agregado exitosamente!")

    def _agregar_recursivo(self, nodo_actual, nuevo_nodo):
        if nodo_actual.siguiente is None:
            nodo_actual.siguiente = nuevo_nodo
            nuevo_nodo.anterior = nodo_actual
            self.cola = nuevo_nodo
        else:
            self._agregar_recursivo(nodo_actual.siguiente, nuevo_nodo)
    def buscar_alumno(self, nombre):
        actual = self.cabeza
        while actual:
            if actual.nombre.lower() == nombre.lower():
                return actual
            actual = actual.siguiente
        return None
    def obtener_calificacion_mas_alta(self):
        if self.esta_vacia():
            return None, None

        nodo_max_cal = self.cabeza
        actual = self.cabeza.siguiente
        while actual:
            if actual.calificacion > nodo_max_cal.calificacion:
                nodo_max_cal = actual
            actual = actual.siguiente
        return nodo_max_cal.nombre, nodo_max_cal.calificacion

    def obtener_calificacion_mas_baja(self):
        if self.esta_vacia():
            return None, None

        nodo_min_cal = self.cabeza
        actual = self.cabeza.siguiente
        while actual:
            if actual.calificacion < nodo_min_cal.calificacion:
                nodo_min_cal = actual
            actual = actual.siguiente
        return nodo_min_cal.nombre, nodo_min_cal.calificacion
def menu():
    lista_alumnos = ListaDoblementeLigada()

    while True:
        print("="*35)
        print("""
        MENÚ DE GESTIÓN DE ALUMNOS")
        1. Agregar Alumno")
        2. Buscar Datos de Alumno")
        3. Mostrar Calificaciones (Alta y Baja)")
        4. Salir""")
        print("-"*35)
        
        opcion = input("Seleccione una opción: ")

        if opcion == '1':
            nombre = input("Ingrese el nombre del alumno: ")
            while True:
                try:
                    calificacion = float(input(f"Ingrese la calificación de {nombre}: "))
                    break
                except ValueError:
                    print("Error: Ingrese un número válido para la calificación.")
            lista_alumnos.agregar_alumno(nombre, calificacion)

        elif opcion == '2':
            if lista_alumnos.esta_vacia():
                print("La lista está vacía. No hay alumnos para buscar.")
                continue
            nombre_buscar = input("Ingrese el nombre del alumno a buscar: ")
            alumno_encontrado = lista_alumnos.buscar_alumno(nombre_buscar)
            if alumno_encontrado:
                print("\n--- Datos del Alumno Encontrado ---")
                print(f"   Nombre:       {alumno_encontrado.nombre}")
                print(f"   Calificación: {alumno_encontrado.calificacion}")
            else:
                print(f"❌ El alumno '{nombre_buscar}' no fue encontrado.")

        elif opcion == '3':
            if lista_alumnos.esta_vacia():
                print("La lista está vacía. No se pueden mostrar calificaciones.")
                continue
            
            print("\n---Resumen de Calificaciones ---")
            nombre_alta, cal_alta = lista_alumnos.obtener_calificacion_mas_alta()
            print(f"   Calificación más ALTA: {cal_alta} (Alumno: {nombre_alta})")

            nombre_baja, cal_baja = lista_alumnos.obtener_calificacion_mas_baja()
            print(f"   Calificación más BAJA: {cal_baja} (Alumno: {nombre_baja})")

        elif opcion == '4':
            print("Saliendo del programa. ¡Hasta luego!")
            break
        else:
            print("X Opción no válida. Por favor, intente de nuevo.")

if __name__ == "__main__":
    menu()